'''
UBC Eye Movement Data Analysis Toolkit
'''
#__all__ = ["Participant", "Scene", "Segment", "Recording", "AOI"]
